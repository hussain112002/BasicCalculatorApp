package com.example.mycalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;




public class MainActivity extends AppCompatActivity {
    TextView result;
    TextView solution;
    Button btnseven, btnequals, btnone, btntwo, btnthree, btnfour, btnfive, btnsix, btneight, btnnine, btnzero, btnmultiply;
    Button btnminus, btnplus, btndivide, btnleftbrac, btndot, btnpercentage, btnclr, btnac;

    String button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.result);
        solution = findViewById(R.id.solution);
        btnleftbrac = findViewById(R.id.btnleftbrac);
        btnone = findViewById(R.id.btnone);
        btnac = findViewById(R.id.btnac);
        btnequals = findViewById(R.id.btnequals);
        btntwo = findViewById(R.id.btntwo);
        btnthree = findViewById(R.id.btnthree);
        btnfour = findViewById(R.id.btnfour);
        btnfive = findViewById(R.id.btnfive);
        btnsix = findViewById(R.id.btnsix);
        btnseven = findViewById(R.id.btnseven);
        btneight = findViewById(R.id.btneight);
        btnnine = findViewById(R.id.btnnine);
        btnzero = findViewById(R.id.btnzero);
        btnmultiply = findViewById(R.id.btnmultiply);
        btndivide = findViewById(R.id.btndivide);
        btnplus = findViewById(R.id.btnplus);
        btnminus = findViewById(R.id.btnminus);
        btndot = findViewById(R.id.btndot);
        btnclr = findViewById(R.id.btnclr);
        btnpercentage = findViewById(R.id.btnpercentage);


        btnclr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = button.substring(0, button.length() - 1);
                result.setText(button);
            }
        });
        btnzero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "0");
            }
        });
        btnac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText("0");
                button = solution.getText().toString();
                solution.setText("0");
            }
        });

        btnone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "1");
            }
        });

        btntwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "2");
            }
        });
        btnthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "3");
            }
        });
        btnfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "4");
            }
        });
        btnfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "5");
            }
        });
        btnsix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "6");
            }
        });
        btnseven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "7");
            }
        });
        btneight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "8");
            }
        });
        btnnine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "9");
            }
        });
        btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "+");
            }
        });


        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "-");
            }
        });
        btnmultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "*");
            }
        });
        btndivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "/");
            }
        });

        btndot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + ".");
            }
        });
        btnpercentage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = result.getText().toString();
                result.setText(button + "%");
            }
        });
        btnequals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button = solution.getText().toString();
                solution.setText(button);

            }

            ;


        });
    }
}